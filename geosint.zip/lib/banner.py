#!/usr/bin/env python3

import os

__version__ = 'v1.4'

def banner():
    print("")
    os.system("cat banner/banner.txt")
    print("")
